"""Top-level public API.

`render_markdown_to_pdf` is the only function callers need: pass a Markdown
string, a brand config and (optionally) layout options, get back PDF bytes.

`reference_brand()` provides a neutral reference identity built from the
assets bundled in this package — used by tests and as a reference preset.
"""

from __future__ import annotations

import io
from pathlib import Path

from reportlab.pdfgen import canvas

from .config import BrandColors, BrandConfig, BrandFonts, LayoutOptions
from .parser import parse_markdown
from .renderer import render_blocks_to_canvas


_PACKAGE_ASSETS = Path(__file__).resolve().parent / "assets"


def reference_brand() -> BrandConfig:
    """Neutral reference brand built from the assets bundled in this package."""
    fonts_dir = _PACKAGE_ASSETS / "fonts"
    return BrandConfig(
        name="Reference",
        colors=BrandColors(
            primary_dark="#26292E",
            primary_light="#D8DBDF",
            primary_mid="#4E545C",
        ),
        fonts=BrandFonts(
            family="Poppins",
            regular=fonts_dir / "Poppins-Regular.ttf",
            bold=fonts_dir / "Poppins-Bold.ttf",
            medium=fonts_dir / "Poppins-Medium.ttf",
            light=fonts_dir / "Poppins-Light.ttf",
            italic=fonts_dir / "Poppins-Italic.ttf",
        ),
        logo_path=None,
        logo_fallback_text="",
        document_author="Mi Marca",
    )


def render_markdown_to_pdf(
    md_text: str,
    brand: BrandConfig,
    layout: LayoutOptions | None = None,
    base_path: str | Path | None = None,
    formulas: dict | None = None,
) -> bytes:
    """Render a Markdown document (with optional YAML frontmatter) to PDF bytes.

    `base_path` is the directory that relative image paths in the markdown
    (`![](img.png)`) are resolved against. When None, relative images cannot be
    located and render as a soft "imagen no disponible" note.

    `formulas` maps a formula id (e.g. "F0") to ``{"path", "ex_w", "ex_h",
    "display"}`` for math pre-rasterized to PNG by the web layer. The markdown
    carries a ``⟦F0⟧`` marker where each formula goes (see the parser).
    """
    layout = layout or LayoutOptions()
    meta, blocks = parse_markdown(md_text)

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=layout.page_size)
    c.setTitle(str(meta.get("titulo") or "Documento"))
    if brand.document_author:
        c.setAuthor(brand.document_author)

    bp = Path(base_path) if base_path is not None else None
    render_blocks_to_canvas(c, meta, blocks, brand, layout, bp, formulas)
    c.save()
    return buf.getvalue()


def render_markdown_to_docx(
    md_text: str,
    brand: BrandConfig,
    layout: LayoutOptions | None = None,
    base_path: str | Path | None = None,
) -> bytes:
    """Render a Markdown document (with optional YAML frontmatter) to DOCX bytes.

    Needs the optional ``docx`` extra (python-docx); imported here so PDF-only
    sessions never load it.
    """
    from .docx_renderer import render_markdown_to_docx as _render_docx

    return _render_docx(md_text, brand, layout, base_path)
